package dataAnalyticsProjectDataCuration.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class DataAnalyticsProjectDataCurationNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public DataAnalyticsProjectDataCurationNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
