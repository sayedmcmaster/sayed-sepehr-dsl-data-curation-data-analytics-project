package dataAnalyticsProjectDataCuration.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizardTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String DataAnalyticsProjectDataCurationModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
