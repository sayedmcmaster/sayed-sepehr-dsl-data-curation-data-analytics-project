package dataAnalyticsProjectDataCuration.diagram.edit.helpers;

/**
 * @generated
 */
public class DataAnalyticsProjectDataCurationEditHelper
		extends dataAnalyticsProjectDataCuration.diagram.edit.helpers.DataAnalyticsProjectDataCurationBaseEditHelper {
}
