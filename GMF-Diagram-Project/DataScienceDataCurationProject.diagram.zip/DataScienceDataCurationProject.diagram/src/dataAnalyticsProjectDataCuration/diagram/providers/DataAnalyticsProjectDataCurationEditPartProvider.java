package dataAnalyticsProjectDataCuration.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class DataAnalyticsProjectDataCurationEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public DataAnalyticsProjectDataCurationEditPartProvider() {
		super(new dataAnalyticsProjectDataCuration.diagram.edit.parts.DataAnalyticsProjectDataCurationEditPartFactory(),
				dataAnalyticsProjectDataCuration.diagram.part.DataAnalyticsProjectDataCurationVisualIDRegistry.TYPED_INSTANCE,
				dataAnalyticsProjectDataCuration.diagram.edit.parts.DataAnalyticsProjectDataCurationEditPart.MODEL_ID);
	}

}
