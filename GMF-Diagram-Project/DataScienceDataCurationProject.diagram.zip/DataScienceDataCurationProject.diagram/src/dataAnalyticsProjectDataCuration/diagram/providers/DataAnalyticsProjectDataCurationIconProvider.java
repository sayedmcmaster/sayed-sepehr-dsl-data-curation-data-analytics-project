package dataAnalyticsProjectDataCuration.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class DataAnalyticsProjectDataCurationIconProvider extends DefaultElementTypeIconProvider
		implements IIconProvider {

	/**
	* @generated
	*/
	public DataAnalyticsProjectDataCurationIconProvider() {
		super(dataAnalyticsProjectDataCuration.diagram.providers.DataAnalyticsProjectDataCurationElementTypes.TYPED_INSTANCE);
	}

}
