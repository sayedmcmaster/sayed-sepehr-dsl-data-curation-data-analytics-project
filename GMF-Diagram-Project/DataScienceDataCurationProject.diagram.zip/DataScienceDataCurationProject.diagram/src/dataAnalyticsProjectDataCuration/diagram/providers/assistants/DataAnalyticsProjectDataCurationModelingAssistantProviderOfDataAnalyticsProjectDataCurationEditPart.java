package dataAnalyticsProjectDataCuration.diagram.providers.assistants;

/**
 * @generated
 */
public class DataAnalyticsProjectDataCurationModelingAssistantProviderOfDataAnalyticsProjectDataCurationEditPart extends
		dataAnalyticsProjectDataCuration.diagram.providers.DataAnalyticsProjectDataCurationModelingAssistantProvider {

}
