package dataCurationStateTransitionAction.diagram.part;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * @generated
 */
public class DataCurationStateTransitionActionCreationWizard extends Wizard implements INewWizard {

	/**
	* @generated
	*/
	private IWorkbench workbench;

	/**
	* @generated
	*/
	protected IStructuredSelection selection;

	/**
	* @generated
	*/
	protected dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionCreationWizardPage diagramModelFilePage;

	/**
	* @generated
	*/
	protected dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionCreationWizardPage domainModelFilePage;

	/**
	* @generated
	*/
	protected Resource diagram;

	/**
	* @generated
	*/
	private boolean openNewlyCreatedDiagramEditor = true;

	/**
	* @generated
	*/
	public IWorkbench getWorkbench() {
		return workbench;
	}

	/**
	* @generated
	*/
	public IStructuredSelection getSelection() {
		return selection;
	}

	/**
	* @generated
	*/
	public final Resource getDiagram() {
		return diagram;
	}

	/**
	* @generated
	*/
	public final boolean isOpenNewlyCreatedDiagramEditor() {
		return openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void setOpenNewlyCreatedDiagramEditor(boolean openNewlyCreatedDiagramEditor) {
		this.openNewlyCreatedDiagramEditor = openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.workbench = workbench;
		this.selection = selection;
		setWindowTitle(
				dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizardTitle);
		setDefaultPageImageDescriptor(
				dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorPlugin
						.getBundledImageDescriptor("icons/wizban/NewDataCurationStateTransitionActionWizard.gif")); //$NON-NLS-1$
		setNeedsProgressMonitor(true);
	}

	/**
	* @generated
	*/
	public void addPages() {
		diagramModelFilePage = new dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionCreationWizardPage(
				"DiagramModelFile", getSelection(), "datacurationstatetransitionaction_diagram"); //$NON-NLS-1$ //$NON-NLS-2$
		diagramModelFilePage.setTitle(
				dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizard_DiagramModelFilePageTitle);
		diagramModelFilePage.setDescription(
				dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizard_DiagramModelFilePageDescription);
		addPage(diagramModelFilePage);

		domainModelFilePage = new dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionCreationWizardPage(
				"DomainModelFile", getSelection(), "datacurationstatetransitionaction") { //$NON-NLS-1$ //$NON-NLS-2$

			public void setVisible(boolean visible) {
				if (visible) {
					String fileName = diagramModelFilePage.getFileName();
					fileName = fileName.substring(0,
							fileName.length() - ".datacurationstatetransitionaction_diagram".length()); //$NON-NLS-1$
					setFileName(
							dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorUtil
									.getUniqueFileName(getContainerFullPath(), fileName,
											"datacurationstatetransitionaction")); //$NON-NLS-1$
				}
				super.setVisible(visible);
			}
		};
		domainModelFilePage.setTitle(
				dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizard_DomainModelFilePageTitle);
		domainModelFilePage.setDescription(
				dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizard_DomainModelFilePageDescription);
		addPage(domainModelFilePage);
	}

	/**
	* @generated
	*/
	public boolean performFinish() {
		IRunnableWithProgress op = new WorkspaceModifyOperation(null) {

			protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
				diagram = dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorUtil
						.createDiagram(diagramModelFilePage.getURI(), domainModelFilePage.getURI(), monitor);
				if (isOpenNewlyCreatedDiagramEditor() && diagram != null) {
					try {
						dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorUtil
								.openDiagram(diagram);
					} catch (PartInitException e) {
						ErrorDialog.openError(getContainer().getShell(),
								dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizardOpenEditorError,
								null, e.getStatus());
					}
				}
			}
		};
		try {
			getContainer().run(false, true, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof CoreException) {
				ErrorDialog.openError(getContainer().getShell(),
						dataCurationStateTransitionAction.diagram.part.Messages.DataCurationStateTransitionActionCreationWizardCreationError,
						null, ((CoreException) e.getTargetException()).getStatus());
			} else {
				dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorPlugin
						.getInstance().logError("Error creating diagram", e.getTargetException()); //$NON-NLS-1$
			}
			return false;
		}
		return diagram != null;
	}
}
