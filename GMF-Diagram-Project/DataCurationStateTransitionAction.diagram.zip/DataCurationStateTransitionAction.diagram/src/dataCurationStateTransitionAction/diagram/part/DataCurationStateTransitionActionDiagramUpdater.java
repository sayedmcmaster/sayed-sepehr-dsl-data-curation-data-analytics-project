package dataCurationStateTransitionAction.diagram.part;

import java.util.Collections;
import java.util.List;

import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class DataCurationStateTransitionActionDiagramUpdater {

	/**
	* @generated
	*/
	public static List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionNodeDescriptor> getSemanticChildren(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getContainedLinks(
			View view) {
		switch (dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionVisualIDRegistry
				.getVisualID(view)) {
		case dataCurationStateTransitionAction.diagram.edit.parts.DataCurationStateTransitionActionEditPart.VISUAL_ID:
			return getDataCurationStateTransitionAction_1000ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getIncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getOutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getDataCurationStateTransitionAction_1000ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/

		public List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionNodeDescriptor> getSemanticChildren(
				View view) {
			return DataCurationStateTransitionActionDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/

		public List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getContainedLinks(
				View view) {
			return DataCurationStateTransitionActionDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/

		public List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getIncomingLinks(
				View view) {
			return DataCurationStateTransitionActionDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/

		public List<dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionLinkDescriptor> getOutgoingLinks(
				View view) {
			return DataCurationStateTransitionActionDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
