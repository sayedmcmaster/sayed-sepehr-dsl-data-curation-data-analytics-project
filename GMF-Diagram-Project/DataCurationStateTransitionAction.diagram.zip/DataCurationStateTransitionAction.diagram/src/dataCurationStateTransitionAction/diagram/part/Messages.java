package dataCurationStateTransitionAction.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizardTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String DataCurationStateTransitionActionModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
