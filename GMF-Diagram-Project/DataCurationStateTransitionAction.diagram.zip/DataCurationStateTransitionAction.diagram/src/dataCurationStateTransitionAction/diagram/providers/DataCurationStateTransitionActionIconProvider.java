package dataCurationStateTransitionAction.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class DataCurationStateTransitionActionIconProvider extends DefaultElementTypeIconProvider
		implements IIconProvider {

	/**
	* @generated
	*/
	public DataCurationStateTransitionActionIconProvider() {
		super(dataCurationStateTransitionAction.diagram.providers.DataCurationStateTransitionActionElementTypes.TYPED_INSTANCE);
	}

}
