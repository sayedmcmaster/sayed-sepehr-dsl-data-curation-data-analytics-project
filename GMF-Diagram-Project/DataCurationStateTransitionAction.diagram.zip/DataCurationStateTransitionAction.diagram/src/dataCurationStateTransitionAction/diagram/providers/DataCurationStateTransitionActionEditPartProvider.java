package dataCurationStateTransitionAction.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class DataCurationStateTransitionActionEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public DataCurationStateTransitionActionEditPartProvider() {
		super(new dataCurationStateTransitionAction.diagram.edit.parts.DataCurationStateTransitionActionEditPartFactory(),
				dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionVisualIDRegistry.TYPED_INSTANCE,
				dataCurationStateTransitionAction.diagram.edit.parts.DataCurationStateTransitionActionEditPart.MODEL_ID);
	}

}
