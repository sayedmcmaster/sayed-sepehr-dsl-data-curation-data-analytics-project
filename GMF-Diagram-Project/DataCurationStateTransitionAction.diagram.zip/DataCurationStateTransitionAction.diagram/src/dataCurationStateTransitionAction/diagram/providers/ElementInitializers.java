package dataCurationStateTransitionAction.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	* @generated
	*/
	public static ElementInitializers getInstance() {
		ElementInitializers cached = dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorPlugin
				.getInstance().getElementInitializers();
		if (cached == null) {
			dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorPlugin
					.getInstance().setElementInitializers(cached = new ElementInitializers());
		}
		return cached;
	}
}
