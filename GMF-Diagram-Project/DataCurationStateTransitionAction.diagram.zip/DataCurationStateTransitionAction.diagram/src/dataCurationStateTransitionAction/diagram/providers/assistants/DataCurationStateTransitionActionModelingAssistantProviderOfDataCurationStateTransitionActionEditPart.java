package dataCurationStateTransitionAction.diagram.providers.assistants;

/**
 * @generated
 */
public class DataCurationStateTransitionActionModelingAssistantProviderOfDataCurationStateTransitionActionEditPart
		extends
		dataCurationStateTransitionAction.diagram.providers.DataCurationStateTransitionActionModelingAssistantProvider {

}
