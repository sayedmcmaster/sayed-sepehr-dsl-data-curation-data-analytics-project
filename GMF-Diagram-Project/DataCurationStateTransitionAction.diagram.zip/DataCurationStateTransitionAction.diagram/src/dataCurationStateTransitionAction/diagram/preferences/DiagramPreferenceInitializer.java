package dataCurationStateTransitionAction.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	* @generated
	*/
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		dataCurationStateTransitionAction.diagram.preferences.DiagramGeneralPreferencePage.initDefaults(store);
		dataCurationStateTransitionAction.diagram.preferences.DiagramAppearancePreferencePage.initDefaults(store);
		dataCurationStateTransitionAction.diagram.preferences.DiagramConnectionsPreferencePage.initDefaults(store);
		dataCurationStateTransitionAction.diagram.preferences.DiagramPrintingPreferencePage.initDefaults(store);
		dataCurationStateTransitionAction.diagram.preferences.DiagramRulersAndGridPreferencePage.initDefaults(store);

	}

	/**
	* @generated
	*/
	protected IPreferenceStore getPreferenceStore() {
		return dataCurationStateTransitionAction.diagram.part.DataCurationStateTransitionActionDiagramEditorPlugin
				.getInstance().getPreferenceStore();
	}
}
