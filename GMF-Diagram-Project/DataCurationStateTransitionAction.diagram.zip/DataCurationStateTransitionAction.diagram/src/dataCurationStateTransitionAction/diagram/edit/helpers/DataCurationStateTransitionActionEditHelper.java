package dataCurationStateTransitionAction.diagram.edit.helpers;

/**
 * @generated
 */
public class DataCurationStateTransitionActionEditHelper
		extends dataCurationStateTransitionAction.diagram.edit.helpers.DataCurationStateTransitionActionBaseEditHelper {
}
