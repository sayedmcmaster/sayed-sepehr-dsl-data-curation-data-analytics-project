package fsmidaeda.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizardTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String FsmIdaEdaNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String FsmIdaEdaElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Fsmidaeda1Group_title;

	/**
	* @generated
	*/
	public static String State1CreationTool_title;

	/**
	* @generated
	*/
	public static String State1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Transition2CreationTool_title;

	/**
	* @generated
	*/
	public static String Transition2CreationTool_desc;

	/**
	* @generated
	*/
	public static String StateIncomingTransition3CreationTool_title;

	/**
	* @generated
	*/
	public static String StateIncomingTransition3CreationTool_desc;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_FSMIdaEda_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_State_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_State_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Transition_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Transition_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String FsmIdaEdaModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String FsmIdaEdaModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
