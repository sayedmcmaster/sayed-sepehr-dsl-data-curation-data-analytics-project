package fsmidaeda.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class FsmIdaEdaNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public FsmIdaEdaNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
