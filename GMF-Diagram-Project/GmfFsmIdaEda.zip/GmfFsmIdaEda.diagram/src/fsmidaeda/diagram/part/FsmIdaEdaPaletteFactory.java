
package fsmidaeda.diagram.part;

import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

import fsmidaeda.diagram.providers.FsmIdaEdaElementTypes;

/**
 * @generated
 */
public class FsmIdaEdaPaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createFsmidaeda1Group());
	}

	/**
	* Creates "fsmidaeda" palette tool group
	* @generated
	*/
	private PaletteContainer createFsmidaeda1Group() {
		PaletteGroup paletteContainer = new PaletteGroup(Messages.Fsmidaeda1Group_title);
		paletteContainer.setId("createFsmidaeda1Group"); //$NON-NLS-1$
		paletteContainer.add(createState1CreationTool());
		paletteContainer.add(createTransition2CreationTool());
		paletteContainer.add(createStateIncomingTransition3CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createState1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Messages.State1CreationTool_title,
				Messages.State1CreationTool_desc, Collections.singletonList(FsmIdaEdaElementTypes.State_2001));
		entry.setId("createState1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(FsmIdaEdaElementTypes.getImageDescriptor(FsmIdaEdaElementTypes.State_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTransition2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Messages.Transition2CreationTool_title,
				Messages.Transition2CreationTool_desc,
				Collections.singletonList(FsmIdaEdaElementTypes.Transition_4001));
		entry.setId("createTransition2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(FsmIdaEdaElementTypes.getImageDescriptor(FsmIdaEdaElementTypes.Transition_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStateIncomingTransition3CreationTool() {
		ToolEntry entry = new ToolEntry(Messages.StateIncomingTransition3CreationTool_title,
				Messages.StateIncomingTransition3CreationTool_desc, null, null) {
		};
		entry.setId("createStateIncomingTransition3CreationTool"); //$NON-NLS-1$
		return entry;
	}

}
