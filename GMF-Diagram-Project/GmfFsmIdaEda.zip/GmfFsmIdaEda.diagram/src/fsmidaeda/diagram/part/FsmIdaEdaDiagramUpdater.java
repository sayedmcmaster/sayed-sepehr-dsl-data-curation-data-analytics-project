package fsmidaeda.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

import fsmidaeda.FSMIdaEda;
import fsmidaeda.FsmidaedaPackage;
import fsmidaeda.State;
import fsmidaeda.Transition;
import fsmidaeda.diagram.edit.parts.FSMIdaEdaEditPart;
import fsmidaeda.diagram.edit.parts.StateEditPart;
import fsmidaeda.diagram.edit.parts.TransitionEditPart;
import fsmidaeda.diagram.providers.FsmIdaEdaElementTypes;

/**
 * @generated
 */
public class FsmIdaEdaDiagramUpdater {

	/**
	* @generated
	*/
	public static List<FsmIdaEdaNodeDescriptor> getSemanticChildren(View view) {
		switch (FsmIdaEdaVisualIDRegistry.getVisualID(view)) {
		case FSMIdaEdaEditPart.VISUAL_ID:
			return getFSMIdaEda_1000SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<FsmIdaEdaNodeDescriptor> getFSMIdaEda_1000SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		FSMIdaEda modelElement = (FSMIdaEda) view.getElement();
		LinkedList<FsmIdaEdaNodeDescriptor> result = new LinkedList<FsmIdaEdaNodeDescriptor>();
		for (Iterator<?> it = modelElement.getOwnedState().iterator(); it.hasNext();) {
			State childElement = (State) it.next();
			int visualID = FsmIdaEdaVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == StateEditPart.VISUAL_ID) {
				result.add(new FsmIdaEdaNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<FsmIdaEdaLinkDescriptor> getContainedLinks(View view) {
		switch (FsmIdaEdaVisualIDRegistry.getVisualID(view)) {
		case FSMIdaEdaEditPart.VISUAL_ID:
			return getFSMIdaEda_1000ContainedLinks(view);
		case StateEditPart.VISUAL_ID:
			return getState_2001ContainedLinks(view);
		case TransitionEditPart.VISUAL_ID:
			return getTransition_4001ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<FsmIdaEdaLinkDescriptor> getIncomingLinks(View view) {
		switch (FsmIdaEdaVisualIDRegistry.getVisualID(view)) {
		case StateEditPart.VISUAL_ID:
			return getState_2001IncomingLinks(view);
		case TransitionEditPart.VISUAL_ID:
			return getTransition_4001IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<FsmIdaEdaLinkDescriptor> getOutgoingLinks(View view) {
		switch (FsmIdaEdaVisualIDRegistry.getVisualID(view)) {
		case StateEditPart.VISUAL_ID:
			return getState_2001OutgoingLinks(view);
		case TransitionEditPart.VISUAL_ID:
			return getTransition_4001OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getFSMIdaEda_1000ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getState_2001ContainedLinks(View view) {
		State modelElement = (State) view.getElement();
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		result.addAll(getContainedTypeModelFacetLinks_Transition_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getTransition_4001ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getState_2001IncomingLinks(View view) {
		State modelElement = (State) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_Transition_4001(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getTransition_4001IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getState_2001OutgoingLinks(View view) {
		State modelElement = (State) view.getElement();
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_Transition_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<FsmIdaEdaLinkDescriptor> getTransition_4001OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	private static Collection<FsmIdaEdaLinkDescriptor> getContainedTypeModelFacetLinks_Transition_4001(
			State container) {
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		for (Iterator<?> links = container.getOutgoingTransition().iterator(); links.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Transition) {
				continue;
			}
			Transition link = (Transition) linkObject;
			if (TransitionEditPart.VISUAL_ID != FsmIdaEdaVisualIDRegistry.getLinkWithClassVisualID(link)) {
				continue;
			}
			State dst = link.getSource();
			State src = link.getSource();
			result.add(new FsmIdaEdaLinkDescriptor(src, dst, link, FsmIdaEdaElementTypes.Transition_4001,
					TransitionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<FsmIdaEdaLinkDescriptor> getIncomingTypeModelFacetLinks_Transition_4001(State target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != FsmidaedaPackage.eINSTANCE.getTransition_Source()
					|| false == setting.getEObject() instanceof Transition) {
				continue;
			}
			Transition link = (Transition) setting.getEObject();
			if (TransitionEditPart.VISUAL_ID != FsmIdaEdaVisualIDRegistry.getLinkWithClassVisualID(link)) {
				continue;
			}
			State src = link.getSource();
			result.add(new FsmIdaEdaLinkDescriptor(src, target, link, FsmIdaEdaElementTypes.Transition_4001,
					TransitionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<FsmIdaEdaLinkDescriptor> getOutgoingTypeModelFacetLinks_Transition_4001(State source) {
		State container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element.eContainer()) {
			if (element instanceof State) {
				container = (State) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<FsmIdaEdaLinkDescriptor> result = new LinkedList<FsmIdaEdaLinkDescriptor>();
		for (Iterator<?> links = container.getOutgoingTransition().iterator(); links.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Transition) {
				continue;
			}
			Transition link = (Transition) linkObject;
			if (TransitionEditPart.VISUAL_ID != FsmIdaEdaVisualIDRegistry.getLinkWithClassVisualID(link)) {
				continue;
			}
			State dst = link.getSource();
			State src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new FsmIdaEdaLinkDescriptor(src, dst, link, FsmIdaEdaElementTypes.Transition_4001,
					TransitionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/

		public List<FsmIdaEdaNodeDescriptor> getSemanticChildren(View view) {
			return FsmIdaEdaDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/

		public List<FsmIdaEdaLinkDescriptor> getContainedLinks(View view) {
			return FsmIdaEdaDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/

		public List<FsmIdaEdaLinkDescriptor> getIncomingLinks(View view) {
			return FsmIdaEdaDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/

		public List<FsmIdaEdaLinkDescriptor> getOutgoingLinks(View view) {
			return FsmIdaEdaDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
