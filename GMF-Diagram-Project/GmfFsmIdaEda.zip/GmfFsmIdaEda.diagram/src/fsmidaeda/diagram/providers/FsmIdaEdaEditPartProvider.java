package fsmidaeda.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

import fsmidaeda.diagram.edit.parts.FSMIdaEdaEditPart;
import fsmidaeda.diagram.edit.parts.FsmIdaEdaEditPartFactory;
import fsmidaeda.diagram.part.FsmIdaEdaVisualIDRegistry;

/**
 * @generated
 */
public class FsmIdaEdaEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public FsmIdaEdaEditPartProvider() {
		super(new FsmIdaEdaEditPartFactory(), FsmIdaEdaVisualIDRegistry.TYPED_INSTANCE, FSMIdaEdaEditPart.MODEL_ID);
	}

}
