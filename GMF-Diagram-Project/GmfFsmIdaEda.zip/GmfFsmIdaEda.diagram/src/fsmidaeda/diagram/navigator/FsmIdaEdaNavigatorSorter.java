package fsmidaeda.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

import fsmidaeda.diagram.part.FsmIdaEdaVisualIDRegistry;

/**
 * @generated
 */
public class FsmIdaEdaNavigatorSorter extends ViewerSorter {

	/**
	* @generated
	*/
	private static final int GROUP_CATEGORY = 4003;

	/**
	* @generated
	*/
	public int category(Object element) {
		if (element instanceof FsmIdaEdaNavigatorItem) {
			FsmIdaEdaNavigatorItem item = (FsmIdaEdaNavigatorItem) element;
			return FsmIdaEdaVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
