package fsmidaeda.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import fsmidaeda.diagram.part.FsmIdaEdaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(FsmIdaEdaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
