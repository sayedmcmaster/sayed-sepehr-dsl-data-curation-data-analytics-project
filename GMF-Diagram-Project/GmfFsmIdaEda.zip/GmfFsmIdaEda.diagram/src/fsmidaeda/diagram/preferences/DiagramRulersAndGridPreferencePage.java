package fsmidaeda.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import fsmidaeda.diagram.part.FsmIdaEdaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(FsmIdaEdaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
