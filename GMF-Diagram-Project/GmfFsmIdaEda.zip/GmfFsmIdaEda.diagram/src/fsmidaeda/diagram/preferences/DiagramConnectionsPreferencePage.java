package fsmidaeda.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

import fsmidaeda.diagram.part.FsmIdaEdaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(FsmIdaEdaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
