package fsmidaeda.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import fsmidaeda.diagram.part.FsmIdaEdaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(FsmIdaEdaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
