package fsmidaeda.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

import fsmidaeda.diagram.part.FsmIdaEdaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	* @generated
	*/
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(FsmIdaEdaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
