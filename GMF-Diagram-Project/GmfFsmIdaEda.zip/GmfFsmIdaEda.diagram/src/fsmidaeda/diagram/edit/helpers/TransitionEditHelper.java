package fsmidaeda.diagram.edit.helpers;

/**
 * @generated
 */
public class TransitionEditHelper extends FsmIdaEdaBaseEditHelper {
}
