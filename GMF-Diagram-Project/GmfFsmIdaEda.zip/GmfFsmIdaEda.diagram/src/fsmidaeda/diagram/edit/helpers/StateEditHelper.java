package fsmidaeda.diagram.edit.helpers;

/**
 * @generated
 */
public class StateEditHelper extends FsmIdaEdaBaseEditHelper {
}
