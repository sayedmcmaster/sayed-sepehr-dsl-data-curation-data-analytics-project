package fsmidaeda.diagram.edit.helpers;

/**
 * @generated
 */
public class FSMIdaEdaEditHelper extends FsmIdaEdaBaseEditHelper {
}
