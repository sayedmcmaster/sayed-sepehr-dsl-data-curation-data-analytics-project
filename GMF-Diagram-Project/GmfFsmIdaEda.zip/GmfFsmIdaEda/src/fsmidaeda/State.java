/**
 */
package fsmidaeda;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fsmidaeda.State#getOwningFSMIdaEda <em>Owning FSM Ida Eda</em>}</li>
 *   <li>{@link fsmidaeda.State#getName <em>Name</em>}</li>
 *   <li>{@link fsmidaeda.State#getOutgoingTransition <em>Outgoing Transition</em>}</li>
 *   <li>{@link fsmidaeda.State#getIncomingTransition <em>Incoming Transition</em>}</li>
 * </ul>
 *
 * @see fsmidaeda.FsmidaedaPackage#getState()
 * @model
 * @generated
 */
public interface State extends EObject {
	/**
	 * Returns the value of the '<em><b>Owning FSM Ida Eda</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fsmidaeda.FSMIdaEda#getOwnedState <em>Owned State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owning FSM Ida Eda</em>' container reference.
	 * @see #setOwningFSMIdaEda(FSMIdaEda)
	 * @see fsmidaeda.FsmidaedaPackage#getState_OwningFSMIdaEda()
	 * @see fsmidaeda.FSMIdaEda#getOwnedState
	 * @model opposite="ownedState" required="true" transient="false"
	 * @generated
	 */
	FSMIdaEda getOwningFSMIdaEda();

	/**
	 * Sets the value of the '{@link fsmidaeda.State#getOwningFSMIdaEda <em>Owning FSM Ida Eda</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owning FSM Ida Eda</em>' container reference.
	 * @see #getOwningFSMIdaEda()
	 * @generated
	 */
	void setOwningFSMIdaEda(FSMIdaEda value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see fsmidaeda.FsmidaedaPackage#getState_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link fsmidaeda.State#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Outgoing Transition</b></em>' containment reference list.
	 * The list contents are of type {@link fsmidaeda.Transition}.
	 * It is bidirectional and its opposite is '{@link fsmidaeda.Transition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoing Transition</em>' containment reference list.
	 * @see fsmidaeda.FsmidaedaPackage#getState_OutgoingTransition()
	 * @see fsmidaeda.Transition#getSource
	 * @model opposite="source" containment="true"
	 * @generated
	 */
	EList<Transition> getOutgoingTransition();

	/**
	 * Returns the value of the '<em><b>Incoming Transition</b></em>' reference list.
	 * The list contents are of type {@link fsmidaeda.Transition}.
	 * It is bidirectional and its opposite is '{@link fsmidaeda.Transition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incoming Transition</em>' reference list.
	 * @see fsmidaeda.FsmidaedaPackage#getState_IncomingTransition()
	 * @see fsmidaeda.Transition#getTarget
	 * @model opposite="target"
	 * @generated
	 */
	EList<Transition> getIncomingTransition();

} // State
