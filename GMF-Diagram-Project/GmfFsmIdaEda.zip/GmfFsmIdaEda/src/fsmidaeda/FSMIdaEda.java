/**
 */
package fsmidaeda;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>FSM Ida Eda</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fsmidaeda.FSMIdaEda#getOwnedState <em>Owned State</em>}</li>
 *   <li>{@link fsmidaeda.FSMIdaEda#getInitialState <em>Initial State</em>}</li>
 *   <li>{@link fsmidaeda.FSMIdaEda#getFinalState <em>Final State</em>}</li>
 * </ul>
 *
 * @see fsmidaeda.FsmidaedaPackage#getFSMIdaEda()
 * @model
 * @generated
 */
public interface FSMIdaEda extends EObject {
	/**
	 * Returns the value of the '<em><b>Owned State</b></em>' containment reference list.
	 * The list contents are of type {@link fsmidaeda.State}.
	 * It is bidirectional and its opposite is '{@link fsmidaeda.State#getOwningFSMIdaEda <em>Owning FSM Ida Eda</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned State</em>' containment reference list.
	 * @see fsmidaeda.FsmidaedaPackage#getFSMIdaEda_OwnedState()
	 * @see fsmidaeda.State#getOwningFSMIdaEda
	 * @model opposite="owningFSMIdaEda" containment="true"
	 * @generated
	 */
	EList<State> getOwnedState();

	/**
	 * Returns the value of the '<em><b>Initial State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial State</em>' reference.
	 * @see #setInitialState(State)
	 * @see fsmidaeda.FsmidaedaPackage#getFSMIdaEda_InitialState()
	 * @model required="true"
	 * @generated
	 */
	State getInitialState();

	/**
	 * Sets the value of the '{@link fsmidaeda.FSMIdaEda#getInitialState <em>Initial State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial State</em>' reference.
	 * @see #getInitialState()
	 * @generated
	 */
	void setInitialState(State value);

	/**
	 * Returns the value of the '<em><b>Final State</b></em>' reference list.
	 * The list contents are of type {@link fsmidaeda.State}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Final State</em>' reference list.
	 * @see fsmidaeda.FsmidaedaPackage#getFSMIdaEda_FinalState()
	 * @model required="true"
	 * @generated
	 */
	EList<State> getFinalState();

} // FSMIdaEda
