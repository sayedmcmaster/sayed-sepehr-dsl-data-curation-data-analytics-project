/**
 */
package fsmidaeda.tests;

import fsmidaeda.FSMIdaEda;
import fsmidaeda.FsmidaedaFactory;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>FSM Ida Eda</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class FSMIdaEdaTest extends TestCase {

	/**
	 * The fixture for this FSM Ida Eda test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FSMIdaEda fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(FSMIdaEdaTest.class);
	}

	/**
	 * Constructs a new FSM Ida Eda test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSMIdaEdaTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this FSM Ida Eda test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(FSMIdaEda fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this FSM Ida Eda test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FSMIdaEda getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(FsmidaedaFactory.eINSTANCE.createFSMIdaEda());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //FSMIdaEdaTest
